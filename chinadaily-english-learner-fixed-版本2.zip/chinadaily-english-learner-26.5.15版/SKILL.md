---
name: chinadaily-english-learner
description: 从喜马拉雅China Daily频道获取英语新闻文章，自动生成完整学习材料。包括：原文摘抄、中英对照翻译、50个核心单词提炼、单词记忆卡片（含AI场景图片）、全文中文翻译、音频链接。自动去重检查Excel记录（"目录"sheet）、完成后写入Excel新行（"目录"sheet）和50个单词（"单词"sheet）、同时产出MD和Word两种格式文档。使用场景：用户要求学习英语、China Daily学习、英语新闻学习、背单词、生成英语学习材料。
---

# China Daily 英语学习助手

## 功能概述

本skill从喜马拉雅China Daily频道（https://xima.tv/1_uyoIoG?_sonic=0）获取最新英语新闻，按日期生成完整学习材料。

## 关键路径（务必记录）

| 用途 | 路径 |
|------|------|
| **套件Excel** | `D:\公司AI\#产出\英语文章、联想记忆法小程序\@套件\@套件.xlsx` |
| **输出根目录** | `D:\公司AI\#产出\英语文章、联想记忆法小程序\` |
| **学习日报存放** | `outputs/chinadaily-learning/{日期}/` （workspace内） |
| **喜马拉雅频道** | https://xima.tv/1_uyoIoG?_sonic=0 |

## 工作流程

### 步骤0：获取当天日期

```bash
date
```

记录日期格式：YYYY年M月D日（如：2026年5月14日）

### 步骤1：读取Excel去重检查（新增）

**必须在爬取文章前执行此步骤！**

使用Python读取套件Excel文件，获取已记录的所有文章标题，避免重复爬取：

```python
import sys
sys.stdout.reconfigure(encoding='utf-8')
import pandas as pd
from openpyxl import load_workbook

EXCEL_PATH = r'D:\公司AI\#产出\英语文章、联想记忆法小程序\@套件\@套件.xlsx'

wb = load_workbook(EXCEL_PATH)
ws = wb['目录']  # 读取"目录"sheet

# 获取已有文章标题列表
existing_titles = []
for row in range(2, ws.max_row + 1):
    title = ws.cell(row=row, column=3).value  # C列=文章标题
    if title:
        existing_titles.append(title)

print(f"已学习文章数量: {len(existing_titles)}")
print(f"已学习标题: {existing_titles}")
# 获取当前最大序号
max_seq = ws.max_row - 1  # 减去表头行
print(f"当前最大序号: {max_seq}")
```

**去重规则**：如果喜马拉雅频道文章标题已出现在`existing_titles`列表中，跳过该文章，选择下一篇。

### 步骤2：访问喜马拉雅China Daily频道

使用浏览器工具访问：
```
https://xima.tv/1_uyoIoG?_sonic=0
```

1. 初始化MCP浏览器标签组
2. 导航到上述URL
3. 获取页面内容，找到最新一期文章
4. **对比去重列表**，跳过已学习的文章，选择新文章

### 步骤3：获取文章详情

1. 从频道列表中选择未学习过的文章（优先最新日期）
2. 在China Daily官网（global.chinadaily.com.cn 或 www.chinadaily.com.cn）搜索对应英文全文
3. 获取文章标题、副标题、作者、更新时间和完整正文内容
4. **确认文章字数 ≥ 250词**，不足则跳过选下一篇

### 步骤4：检查是否已学习（目录级别）

在 `outputs/chinadaily-learning/` 目录下检查是否已有该日期的学习文件夹：
- 如果已存在 → 跳过，提示用户
- 如果不存在 → 继续执行

### 步骤5：生成学习材料（MD + Word）

创建文件夹：`outputs/chinadaily-learning/{YYYY-MM-DD}/`

按以下六步格式生成完整学习材料：

#### 首先：原文摘抄

完整摘抄文章标题和正文内容。

#### 第一：中英对照翻译

逐段进行中英文对照翻译，格式：
```
**英文原文段落**
中文翻译段落
```

#### 第二：提炼50个核心单词

从文章中提炼最核心、考试/写作必用的单词+短语：
- 中英对照、极简好背版
- 格式示例：`attract /əˈtrækt/ v. 吸引`
- 避免重复之前已提炼过的单词
- 不足50个就有多少提炼多少

#### 第三：单词卡片

为每个单词制作可直接背诵、跟读、打印的卡片，格式：
```
attract
- 音标：/əˈtrækt/
- 词性：v.
- 中文：吸引；引起…的注意
- 记忆法：at（加强）+ tract（拉）→ 把人拉过来 → 吸引
- 例句：The city attracts many foreigners every year.（这座城市每年吸引很多外国人。）
```

#### 第四：全文中文翻译

提供流畅、准确的全文纯中文翻译。

#### 第五：音频链接

提供喜马拉雅音频链接：
```
音频链接：https://xima.tv/1_uyoIoG?_sonic=0
```

#### 第六：AI场景记忆卡片

为每个单词生成高质量AI场景记忆图片（1024x1024）：

**图片要求：**
- 每张卡片都有清晰的场景插图
- 包含单词、音标、词性、中文释义
- 记忆法说明（词根/谐音/联想）
- 场景化联想描述
- 例句（中英文对照）

**生成方法：**
使用ImageGen工具，为每个单词生成独立的场景图片。

Prompt模板：
```
Educational vocabulary memory card for "[单词] [音标] [词性] [中文]". 
LEFT: [场景描述，与单词含义相关的生动场景]. 
RIGHT: Large text "[单词]". 
Memory text: "[记忆法说明]". 
Chinese: "[中文例句]". 
Style: educational cartoon illustration, flat design, clear visual metaphor, white background
```

图片保存到：`outputs/chinadaily-learning/{YYYY-MM-DD}/单词卡片/`

### 步骤6：写入Excel记录（新增）

**每完成一篇文章后，必须执行此步骤！**

使用openpyxl将文章信息追加到Excel文件的下一行：

```python
import sys
sys.stdout.reconfigure(encoding='utf-8')
from openpyxl import load_workbook
from datetime import datetime

EXCEL_PATH = r'D:\公司AI\#产出\英语文章、联想记忆法小程序\@套件\@套件.xlsx'

wb = load_workbook(EXCEL_PATH)
ws = wb['目录']  # 写入"目录"sheet

# 确定下一行序号
next_row = ws.max_row + 1
next_seq = next_row - 1  # 序号 = 行号 - 表头行

# 写入新记录
# 字段：序号 | 日期 | 文章标题 | 副标题 | 作者 | 更新时间 | 来源
ws.cell(row=next_row, column=1, value=next_seq)                    # 序号
ws.cell(row=next_row, column=2, value=datetime(2026, 5, 12))       # 日期（用datetime对象）
ws.cell(row=next_row, column=3, value="文章标题")                   # 文章标题
ws.cell(row=next_row, column=4, value="副标题")                     # 副标题
ws.cell(row=next_row, column=5, value="作者")                       # 作者
ws.cell(row=next_row, column=6, value=datetime(2026, 5, 12, 7, 19)) # 更新时间
ws.cell(row=next_row, column=7, value="China Daily via 喜马拉雅")   # 来源

# 设置日期格式
ws.cell(row=next_row, column=2).number_format = 'YYYY"年"M"月"D"日"'
ws.cell(row=next_row, column=6).number_format = 'YYYY/M/D H:MM'

wb.save(EXCEL_PATH)
print(f"已写入第 {next_seq} 条记录")
```

**"目录"sheet字段说明：**

| 列 | 字段名 | 格式 | 示例 |
|----|--------|------|------|
| A | 序号 | 整数 | 1 |
| B | 日期 | 日期格式 | 2026年5月12日 |
| C | 文章标题 | 文本 | Mainland stock market hits 11-year high |
| D | 副标题 | 文本 | A-share listed semiconductor firms fuel rally... |
| E | 作者 | 文本 | Shi Jing in Shanghai \| China Daily |
| F | 更新时间 | 日期时间 | 2026/5/12 7:19 |
| G | 来源 | 文本 | China Daily via 喜马拉雅 |

### 步骤7：生成Word文档（新增）

**除MD文件外，必须同时产出Word(.docx)文档！**

使用python-docx生成格式化的Word文档，内容与MD文档一致：

```python
import sys
sys.stdout.reconfigure(encoding='utf-8')
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH

doc = Document()

# 设置标题
doc.add_heading('China Daily 英语学习日报', level=0)

# 添加元信息
meta = doc.add_paragraph()
meta.add_run('日期: ').bold = True
meta.add_run('2026年5月12日\n')
meta.add_run('文章标题: ').bold = True
meta.add_run('Mainland stock market hits 11-year high\n')
meta.add_run('来源: ').bold = True
meta.add_run('China Daily via 喜马拉雅')

# 按六步法依次添加内容...
doc.add_heading('首先：原文摘抄', level=1)
doc.add_paragraph('...')  # 原文内容

doc.add_heading('第一：中英对照翻译', level=1)
# 英文加粗、中文正常...

doc.add_heading('第二：核心单词（50个）', level=1)
# 编号列表...

doc.add_heading('第三：单词卡片', level=1)
# 卡片格式...

doc.add_heading('第四：全文中文翻译', level=1)
doc.add_paragraph('...')

doc.add_heading('第五：音频链接', level=1)
doc.add_paragraph('...')

# 保存
doc.save('学习日报.docx')
```

Word文档保存路径：`outputs/chinadaily-learning/{YYYY-MM-DD}/学习日报.docx`

### 步骤8：写入单词记录到Excel（新增）

**每完成一篇文章后，必须将50个核心单词写入"单词"sheet！**

```python
import sys
sys.stdout.reconfigure(encoding='utf-8')
from openpyxl import load_workbook
from datetime import datetime

EXCEL_PATH = r'D:\公司AI\#产出\英语文章、联想记忆法小程序\@套件\@套件.xlsx'

wb = load_workbook(EXCEL_PATH)
ws = wb['单词']  # 写入"单词"sheet

# 文章信息
article_seq = next_seq  # 与目录中的文章序号一致
article_date = datetime(2026, 5, 12)
article_title = "文章标题"

# words_data 是由 (单词序号, 单词, 音标, 词性, 释义) 组成的列表
words_data = [
    (1, "word1", "/wɜːrd1/", "n.", "中文释义1"),
    (2, "word2", "/wɜːrd2/", "v.", "中文释义2"),
    # ... 共50个
]

# 找到当前最大行号（从已有数据的下一行开始写入）
start_row = ws.max_row + 1
for i, (word_seq, word, phonetic, pos, meaning) in enumerate(words_data):
    row = start_row + i
    ws.cell(row=row, column=1, value=article_seq)
    ws.cell(row=row, column=2, value=article_date)
    ws.cell(row=row, column=3, value=article_title)
    ws.cell(row=row, column=4, value=word_seq)
    ws.cell(row=row, column=5, value=word)
    ws.cell(row=row, column=6, value=phonetic)
    ws.cell(row=row, column=7, value=pos)
    ws.cell(row=row, column=8, value=meaning)
    ws.cell(row=row, column=2).number_format = 'YYYY"年"M"月"D"日"'

wb.save(EXCEL_PATH)
print(f"已写入 {len(words_data)} 个单词到'单词'sheet")
```

**"单词"sheet字段说明：**

| 列 | 字段名 | 格式 | 示例 |
|----|--------|------|------|
| A | 文章序号 | 整数 | 2 |
| B | 日期 | 日期格式 | 2026年5月12日 |
| C | 文章标题 | 文本 | Head-of-state diplomacy to guide relations |
| D | 单词序号 | 整数 | 1 |
| E | 单词 | 文本 | diplomacy |
| F | 音标 | 文本 | /dɪˈploʊməsi/ |
| G | 词性 | 文本 | n. |
| H | 释义 | 文本 | 外交；外交手腕 |

## 输出文件结构

```
outputs/chinadaily-learning/{YYYY-MM-DD}/
├── 学习日报.md              # Markdown格式完整内容
├── 学习日报.docx            # Word格式（可分享给外部人员）
└── 单词卡片/                # 50个单词的AI场景图片
    ├── 01_word1.png
    ├── 02_word2.png
    └── ...
```

## 学习日报模板

```markdown
# China Daily 英语学习日报

**日期**: 2026年5月14日
**文章标题**: [文章标题]
**副标题**: [副标题]
**作者**: [作者]
**更新时间**: [时间]
**来源**: China Daily via 喜马拉雅

---

## 首先：原文摘抄

**标题**: [完整标题]

[完整正文内容]

---

## 第一：中英对照翻译

[逐段中英对照]

---

## 第二：核心单词（50个）

1. word1 /音标/ 词性. 中文
2. word2 /音标/ 词性. 中文
...

---

## 第三：单词卡片

[50个单词的详细卡片]

---

## 第四：全文中文翻译

[完整中文翻译]

---

## 第五：音频链接

音频链接：https://xima.tv/1_uyoIoG?_sonic=0

---

## 第六：AI场景记忆卡片

[50个单词的场景图片，每个图片下方附说明]
```

## 注意事项

1. **Excel结构**：套件Excel包含两个sheet——"目录"（文章列表）和"单词"（核心单词列表）
2. **Excel去重**：每次执行前必须先读取"目录"sheet，检查文章标题是否已记录，避免重复
3. **Excel写入**：每完成一篇文章后，追加新行到"目录"sheet，同时将50个单词写入"单词"sheet
3. **双格式输出**：同时产出MD文档（内部使用）和Word文档（外部分享）
4. **图片质量**：使用ImageGen生成1024x1024高质量图片
5. **单词去重**：记录已学习的单词，避免重复提炼
6. **保存位置**：所有材料保存到 `outputs/chinadaily-learning/` 目录
7. **执行时间**：生成50张图片需要较长时间，请耐心等待
8. **文章筛选**：只选择250词以上的长文

## 触发条件

当用户提到以下关键词时自动使用此skill：
- China Daily学习
- 英语学习材料
- 背单词
- 英语新闻学习
- 生成学习日报
- 喜马拉雅英语

## 执行顺序总结

```
步骤0：获取日期
    ↓
步骤1：读取Excel"目录"sheet去重检查 ← 避免重复
    ↓
步骤2：访问喜马拉雅频道，选择新文章
    ↓
步骤3：获取China Daily官网完整正文
    ↓
步骤4：检查本地文件夹是否已存在
    ↓
步骤5：生成六步法学习材料（MD格式）
    ↓
步骤6：写入Excel"目录"sheet新行 ← 记录文章
    ↓
步骤7：生成Word文档 ← 供外部分享
    ↓
步骤8：写入Excel"单词"sheet ← 记录50个核心单词
    ↓
完成！输出MD + Word + 50张AI卡片
```
