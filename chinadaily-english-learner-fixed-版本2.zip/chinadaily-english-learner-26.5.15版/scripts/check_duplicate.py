#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
China Daily 学习材料去重检查脚本
检查指定日期的学习材料是否已生成
"""

import os
import sys
from datetime import datetime

def check_date_exists(base_dir, date_str):
    """检查指定日期的学习文件夹是否已存在"""
    # 支持多种日期格式
    date_formats = [
        date_str,  # 原始格式
        date_str.replace('-', ''),  # 无分隔符
        date_str.replace('-', '_'),  # 下划线分隔
    ]
    
    for fmt in date_formats:
        folder_path = os.path.join(base_dir, fmt)
        if os.path.exists(folder_path):
            return True, folder_path
    
    return False, None

def get_learned_words(base_dir):
    """获取已学习过的单词列表"""
    learned_words = set()
    
    # 遍历所有日期文件夹
    if not os.path.exists(base_dir):
        return learned_words
    
    for date_folder in os.listdir(base_dir):
        word_card_dir = os.path.join(base_dir, date_folder, '单词卡片')
        if os.path.exists(word_card_dir):
            # 从文件名提取单词
            for filename in os.listdir(word_card_dir):
                if filename.endswith('.png'):
                    # 文件名格式：01_composite.png
                    word = filename.split('_', 1)[1].replace('.png', '')
                    learned_words.add(word.lower())
    
    return learned_words

def main():
    if len(sys.argv) < 2:
        print("用法: python check_duplicate.py <日期>")
        print("示例: python check_duplicate.py 2026-05-14")
        sys.exit(1)
    
    date_str = sys.argv[1]
    base_dir = os.path.join(os.path.dirname(__file__), '..', '..', 'outputs', 'chinadaily-learning')
    
    # 检查日期是否已学习
    exists, folder_path = check_date_exists(base_dir, date_str)
    
    if exists:
        print(f"EXISTS:{folder_path}")
        print(f"警告：{date_str} 的学习材料已存在！")
        print(f"路径：{folder_path}")
    else:
        print(f"NEW:{date_str}")
        print(f"{date_str} 的学习材料尚未生成，可以开始创建。")
    
    # 获取已学单词
    learned = get_learned_words(base_dir)
    if learned:
        print(f"\n已学习单词数：{len(learned)}")
        print("已学单词列表（用于去重）：")
        for word in sorted(learned):
            print(f"  - {word}")

if __name__ == "__main__":
    main()
