#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
单词卡片Prompt生成器
为每个单词生成AI图片的Prompt
"""

import json
import sys

def generate_prompt(word_data):
    """为单个单词生成ImageGen Prompt"""
    word = word_data['word']
    phonetic = word_data['phonetic']
    pos = word_data['pos']
    chinese = word_data['chinese']
    memory_method = word_data['memory_method']
    scene_description = word_data['scene_description']
    example_en = word_data['example_en']
    example_cn = word_data['example_cn']
    
    prompt = f'''Educational vocabulary memory card for "{word} {phonetic} {pos} {chinese}". 
LEFT: {scene_description}. 
RIGHT: Large text "{word}". 
Memory text: "{memory_method}". 
Chinese: "{example_cn}". 
Style: educational cartoon illustration, flat design, clear visual metaphor, vibrant colors, white background, high quality, detailed'''
    
    return prompt

def generate_batch_prompts(words_file):
    """批量生成单词卡片的Prompts"""
    with open(words_file, 'r', encoding='utf-8') as f:
        words_data = json.load(f)
    
    prompts = []
    for i, word_data in enumerate(words_data, 1):
        prompt = generate_prompt(word_data)
        prompts.append({
            'index': i,
            'word': word_data['word'],
            'prompt': prompt,
            'filename': f"{i:02d}_{word_data['word']}.png"
        })
    
    return prompts

def main():
    if len(sys.argv) < 2:
        print("用法: python generate_prompts.py <单词JSON文件>")
        print("示例: python generate_prompts.py words.json")
        sys.exit(1)
    
    words_file = sys.argv[1]
    prompts = generate_batch_prompts(words_file)
    
    # 输出Prompts
    for p in prompts:
        print(f"\n{'='*60}")
        print(f"单词 #{p['index']}: {p['word']}")
        print(f"文件名: {p['filename']}")
        print(f"{'='*60}")
        print(p['prompt'])
    
    # 保存Prompts到文件
    output_file = words_file.replace('.json', '_prompts.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(prompts, f, ensure_ascii=False, indent=2)
    
    print(f"\nPrompts已保存到: {output_file}")

if __name__ == "__main__":
    main()
