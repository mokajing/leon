# Word Card Generator Skill

Standalone Claude Code skill for batch-generating English vocabulary memory cards.

## Installation

1. Copy the `word-card-generator/` folder to `~/.claude/skills/`
2. Copy `dependencies/generate_image.py` to `~/.claude/skills/generate-image/generate_image.py` (or keep your existing one)
3. Set env var `ANTHROPIC_AUTH_TOKEN` for Ducky API access

## Quick Start

```bash
# Generate cards from a 学习日报.md
python3 ~/.claude/skills/word-card-generator/scripts/batch_generate_cards.py <date_dir>
```

## Input Format

See `examples/sample_daily.md` — needs `## 第三：单词卡片` section with word entries.

## Output

`<date_dir>/单词卡片/01_word.png`, `02_word.png`, ... (1024×1024 PNG each)

## Prompt Template (Fixed)

See `SKILL.md`. Do NOT modify to "scene-based" style — that is a separate task.
