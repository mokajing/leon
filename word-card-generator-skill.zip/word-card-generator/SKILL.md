---
name: word-card-generator
description: 批量生成英语单词联想记忆卡片图片（1024x1024 PNG）。从学习日报.md 解析单词数据（含音标、词性、中文、记忆法、双语例句），调用 Ducky API 生成"左插画 + 右文字"分栏式扁平卡通卡片。支持断点续生、限流重试。当用户需要为英语单词批量产出联想记忆卡片图片时使用本技能。
---

# Word Card Generator Skill

## 功能概述

为英语学习者批量产出"联想记忆法"单词卡片图片。每张卡片 1024×1024 PNG，**左半边插画** + **右半边文字信息**（单词/音标/中文/记忆技巧/双语例句），扁平卡通风格。

## 输入要求

学习日报.md 文件，需包含 `## 第三：单词卡片` section，每个单词用 `### N. word` 标题，下面跟：

```
### 1. deliver
- 音标：/dɪˈlɪvər/
- 词性：v.
- 中文：递送；发表（演讲）
- 记忆法：de（加强）+ liver（自由）→ 把东西从自己手中解放出来 → 递送
- 例句：He delivered a speech at the conference. / 他在会议上发表了演讲。
```

例句字段必须包含 **英文 + " / " + 中文翻译**。

## 输出

在 `<日期目录>/单词卡片/` 下生成 N 张 PNG，命名 `01_deliver.png`、`02_shed.png`...

## 关键路径

| 用途 | 路径 |
|------|------|
| 主脚本 | `scripts/batch_generate_cards.py` |
| 图片生成依赖 | `~/.claude/skills/generate-image/generate_image.py` |
| 输出目录 | `<日期目录>/单词卡片/` |

## 使用方法

```bash
# 单个目录
python3 scripts/batch_generate_cards.py <日期目录>

# 从第 N 个开始，最多生成 M 张
python3 scripts/batch_generate_cards.py <日期目录> <起始序号> <最大数量>

# 示例
python3 scripts/batch_generate_cards.py outputs/chinadaily-learning/2025-02-03
python3 scripts/batch_generate_cards.py outputs/chinadaily-learning/2025-02-03 10 20
```

## 卡片 Prompt 模板（不可更改）

```
Create an educational vocabulary memory card image with this EXACT layout:

LEFT HALF - ILLUSTRATION:
Draw a vivid, colorful cartoon scene that visually represents the word "<word>" (<chinese>).

RIGHT HALF - TEXT INFORMATION:
1. The word "<word>" in large bold font at the top
2. Phonetic: "<phonetic>" below the word
3. Chinese meaning: "<chinese>" (<pos>)
4. A section labeled "记忆技巧" with: "<memory>"
5. A section labeled "例句" with: "<example>" (must include both English sentence AND Chinese translation)

STYLE: Educational cartoon, flat design, split card layout, white background, 1024x1024
```

> ⚠️ 此 prompt 已固定成熟，**不要擅自改为场景化或其它样式**。如需场景化产出，请走独立的"场景化单词素材"任务，不在此 Skill 范围内。

## 断点续生

脚本自动跳过已存在的 PNG 文件，可中断后重新运行。

## 限流处理

- Ducky API 429 时退避 30/60/90 秒，最多重试 3 次
- 每张卡片之间间隔 2 秒

## 输入 MD 模板示例

参见 `examples/sample_daily.md`。

## 触发条件

- 用户说"为这些单词生成卡片"
- 用户说"批量产出联想记忆图片"
- 用户说"给这篇日报配单词卡片"
- 在 China Daily 学习流程的"第六步"
