#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
批量生成单词记忆卡片图片
从学习日报.md解析单词数据，调用Ducky API生成AI场景图片。
支持断点续生、限流重试。

用法：python3 batch_generate_cards.py <日期目录>
例如：python3 batch_generate_cards.py outputs/chinadaily-learning/2025-02-03
"""

import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path.home() / ".claude" / "skills" / "generate-image"))
from generate_image import generate_image

def parse_word_cards(md_path):
    """从学习日报.md解析单词卡片数据"""
    content = Path(md_path).read_text(encoding='utf-8')

    cards_match = re.search(r'## 第三：单词卡片\s*\n(.*?)(?=\n---|\n## 第四)', content, re.DOTALL)
    if not cards_match:
        print("未找到单词卡片section")
        return []

    cards_text = cards_match.group(1).strip()
    words = []
    current = {}

    for line in cards_text.split('\n'):
        if line.startswith('### '):
            if current.get('word'):
                words.append(current)
            title = line.replace('### ', '').strip()
            seq_match = re.match(r'(\d+)\.\s*(.+)', title)
            if seq_match:
                current = {'seq': int(seq_match.group(1)), 'word': seq_match.group(2).strip()}
            else:
                current = {'seq': len(words) + 1, 'word': title}
        elif line.strip().startswith('- 音标：'):
            current['phonetic'] = line.strip().replace('- 音标：', '').strip()
        elif line.strip().startswith('- 词性：'):
            current['pos'] = line.strip().replace('- 词性：', '').strip()
        elif line.strip().startswith('- 中文：'):
            current['chinese'] = line.strip().replace('- 中文：', '').strip()
        elif line.strip().startswith('- 记忆法：'):
            current['memory'] = line.strip().replace('- 记忆法：', '').strip()
        elif line.strip().startswith('- 例句：'):
            current['example'] = line.strip().replace('- 例句：', '').strip()

    if current.get('word'):
        words.append(current)

    return words


def build_prompt(word_data):
    """为单个单词构建图片生成prompt"""
    word = word_data.get('word', '')
    phonetic = word_data.get('phonetic', '')
    pos = word_data.get('pos', '')
    chinese = word_data.get('chinese', '')
    memory = word_data.get('memory', '')
    example = word_data.get('example', '')

    prompt = f"""Create an educational vocabulary memory card image with this EXACT layout:

LEFT HALF - ILLUSTRATION:
Draw a vivid, colorful cartoon scene that visually represents the word "{word}" ({chinese}).

RIGHT HALF - TEXT INFORMATION:
1. The word "{word}" in large bold font at the top
2. Phonetic: "{phonetic}" below the word
3. Chinese meaning: "{chinese}" ({pos})
4. A section labeled "记忆技巧" with: "{memory}"
5. A section labeled "例句" with: "{example}" (must include both English sentence AND Chinese translation)

STYLE: Educational cartoon, flat design, split card layout, white background, 1024x1024"""

    return prompt


def batch_generate(date_dir, start_from=1, max_count=50):
    """批量生成单词卡片"""
    date_dir = Path(date_dir)
    md_path = date_dir / "学习日报.md"

    if not md_path.exists():
        print(f"文件不存在: {md_path}")
        return

    cards_dir = date_dir / "单词卡片"
    cards_dir.mkdir(exist_ok=True)

    words = parse_word_cards(md_path)
    print(f"共解析 {len(words)} 个单词")

    generated = 0
    skipped = 0
    failed = 0

    for word_data in words:
        seq = word_data.get('seq', 0)
        word = word_data.get('word', 'unknown')

        if seq < start_from:
            continue
        if generated >= max_count:
            break

        safe_word = re.sub(r'[^\w\-]', '_', word)[:30]
        output_file = cards_dir / f"{seq:02d}_{safe_word}.png"

        if output_file.exists():
            print(f"[SKIP] #{seq} {word} - 已存在")
            skipped += 1
            continue

        prompt = build_prompt(word_data)

        print(f"[GEN] #{seq}/{len(words)} {word}...", end=" ", flush=True)

        retries = 3
        for attempt in range(retries):
            try:
                result_path = generate_image(
                    prompt=prompt,
                    output_dir=str(cards_dir),
                )
                if result_path and os.path.exists(result_path):
                    os.rename(result_path, str(output_file))
                    print(f"✓")
                    generated += 1
                    break
            except Exception as e:
                err_msg = str(e)
                if "429" in err_msg or "rate" in err_msg.lower():
                    wait = 30 * (attempt + 1)
                    print(f"\n  [RATE LIMIT] 等待{wait}秒...")
                    time.sleep(wait)
                elif attempt < retries - 1:
                    print(f"\n  [RETRY] {e}")
                    time.sleep(5)
                else:
                    print(f"✗ {e}")
                    failed += 1

        time.sleep(2)

    print(f"\n完成！生成: {generated}, 跳过: {skipped}, 失败: {failed}")
    return generated


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 batch_generate_cards.py <日期目录> [起始序号] [最大数量]")
        print("例如: python3 batch_generate_cards.py outputs/chinadaily-learning/2025-02-03")
        sys.exit(1)

    date_dir = sys.argv[1]
    start = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    count = int(sys.argv[3]) if len(sys.argv) > 3 else 50

    batch_generate(date_dir, start_from=start, max_count=count)
